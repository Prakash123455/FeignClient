package com.example.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name = "frstfeignclient",url = "http://localhost:8080/resource")
public interface FeignDemo {

	
	@RequestMapping("/get")
	public String m5();
	@RequestMapping("/getm2")
	public String m6();
	
}
