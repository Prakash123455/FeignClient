package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeignClientController {
	
	@Autowired
	FeignDemo fd;
	
	@RequestMapping("/d1")
	public String getm1()
	{
		return fd.m5();
	}
	
	@RequestMapping("/d2")
	public String getm2()
	{
		return fd.m6();
	}
}
