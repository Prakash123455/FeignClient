package com.example.demo;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("resource")
public class ResourceController {

	
	@GetMapping("/get")
	public String m1()
	{
		return "getting all info of m1()....";
	}
	@GetMapping("/getm2")
	public String m2()
	{
		return "getting all info of m2()....";
	}
	
	
}
